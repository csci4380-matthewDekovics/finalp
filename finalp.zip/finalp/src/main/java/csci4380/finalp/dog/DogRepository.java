package csci4380.finalp.dog;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DogRepository extends MongoRepository<Dog, String>{
	public Optional<Dog> findById(String id);
	public Optional<List<Dog>> findByPetId(Integer petId);
	public Optional<List<Dog>> findByName(String name);
	public Optional<List<Dog>> findByType(String type);
	public Optional<List<Dog>> findByOwnerName(String ownerName);
	public Optional<List<Dog>> findByAddress(String address);
	public Optional<List<Dog>> findByAge(Integer age);
	public Optional<List<Dog>> findByBirthdate(String birthdate);
	public void deleteByPetId(String petId);
	
	@Query("{}")
	public List<Dog> findMyAll();
	@Query("{'name' : ?0")
	public List<Dog> findByNameD(String name);
	@Query("{'name': {$regex: ?0}}")
	public List<Dog> findByRegexp(String regexp);
	@Query("{'age': {$gt: ?0, $lt: ?1}}")
	public List<Dog> findByAgeD(Integer age);
}
