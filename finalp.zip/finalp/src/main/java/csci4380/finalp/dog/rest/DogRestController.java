package csci4380.finalp.dog.rest;

import java.util.List;
import java.util.Optional;

import org.h2.mvstore.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import csci4380.finalp.dog.Dog;
import csci4380.finalp.dog.DogRepository;

@RestController
@RequestMapping("rest/v1/dog")
public class DogRestController {
		private DogRepository dogRepository;
		public DogRestController(DogRepository dogRepository) {
			this.dogRepository = dogRepository;
		}
		@GetMapping("/echoMessage")
		public String echoMessage(@RequestParam(value="msg", defaultValue="Hello ilker") String message) {
			return "echoMessage echoed: " + message;
		}
		@GetMapping("/messageInJsonObject")
		@CrossOrigin(origins={"http://localhost:8888"})
		public String messageInJsonObject(@RequestParam(defaultValue="0") int page, @RequestParam(value="rowsPerPage", defaultValue="5") int size) {
			return message;
		}
		@GetMapping("")
		public Page findAll(@RequestParam(defaultValue="0") int page, @RequestParam(value="rowsPerPage", defaultValue="5") int size) {
			Page dogsPage = (Page) dogRepository.findAll(new PageRequest(page, size));
			return dogsPage;
		}
		@GetMapping("/all")
		public static List<Dog> findAll() {
			List<Dog> dogs = DogRepository.findAll();
			return dogs;
		}
		@GetMapping("/{id}")
		public  Optional<Dog> findById(@PathVariable String id) {
			Optional<Dog> dog = dogRepository.findById(id);
			return dog;
		}
		@GetMapping("/petId/{petId}")
		public  Optional<List<Dog>> findByPetId(@PathVariable Integer petId) {
			Optional<List<Dog>> dogs = dogRepository.findByPetId(petId);
			return dogs;
		}
		@GetMapping("/age{age}")
		public  Optional<List<Dog>> findMyByAge(@PathVariable Integer age) {
			Optional<List<Dog>> dogs = dogRepository.findByAge(age);
			return dogs;
		}
		@PostMapping("")
		public  Optional<Dog> save(@RequestBody final Dog dog) {
			Dog savedDog = dogRepository.save(dog);
			return dogRepository.findById(savedDog.getId());
		}
		@PutMapping("")
		public  Dog insert(@RequestBody final Dog dog) {
			Dog insertedDog = dogRepository.insert(dog);
			return insertedDog;
		}
		@DeleteMapping("/{id}")
		public  void delete(@PathVariable("id") String id) {
			dogRepository.deleteById(id);
		}
		@DeleteMapping("/petId/{petId}")
		public  void deleteByPetId(@PathVariable String petId) {
			dogRepository.deleteByPetId(petId);
		}
	}
