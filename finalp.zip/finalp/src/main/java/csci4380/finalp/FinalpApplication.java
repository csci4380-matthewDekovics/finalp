package csci4380.finalp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalpApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalpApplication.class, args);
	}
}
