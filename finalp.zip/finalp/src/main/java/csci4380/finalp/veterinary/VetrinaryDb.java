package csci4380.finalp.veterinary;

import java.util.Arrays;
import java.util.List;

import csci4380.finalp.Cat;
import csci4380.finalp.CatRepository;
import csci4380.finalp.dog.Dog;
import csci4380.finalp.dog.DogRepository;

public interface VetrinaryDb {
public DogRepository dogRepository;
public CatRepository catRepository;
	
	public default void InitDogMongoDbCollection(DogRepository dogRepository, CatRepository catRepository) {
		this.dogRepository = dogRepository;
		this.catRepository = catRepository;
	}
	public static void run1(String... args) throws Exception {
		Dog t1 = new Dog("1", 1, "Ralph", "German Shepard", "Ryan","123 main st", 32,false, "7/14/1986");
		Dog t2 = new Dog("2", 2, "Arthur", "chihuahua", "Tim", "234 elm st", 23,false, "6/28/1995");
		Dog t3 = new Dog("3", 3, "Gino", "Doberman", "John", "345 corner rd", 34,true, "5/16/1984");
		Dog t4 = new Dog("4", 4, "Diddy", "Husky", "Sean", "456 Greenwood ave", 25,true, "4/20/1993");
		Dog t5 = new Dog("5", 5, "Goat", "Shitzu", "Erik", "567 main st", 26,true, "3/9/1992");
		Dog t6 = new Dog("6", 6, "Max", "Pug", "Gizelle", "678 main st", 37,false, "2/17/1981");
		Dog t7 = new Dog("7", 7, "Ruff", "dachsaund", "Elizabeth","13 drewery ln", 27,false, "1/1/1991");
		
		
		List<Dog> dogs = Arrays.asList(t1,t2,t3,t4,t5,t6,t7);
		dogRepository.saveAll(dogs);
	}
	public static void run(String... args) throws Exception  {
		Cat t1 = new Cat( 1, "Mary", "Ragdoll", "Ryan","123 main st", 32,false, "7/14/1986");
		Cat t2 = new Cat( 2, "Sugar", "British Shorthair", "Tim", "234 elm st", 23,false, "6/28/1995");
		Cat t3 = new Cat( 3, "Oz", "Calico", "John", "345 corner rd", 34,true, "5/16/1984");
		Cat t4 = new Cat( 4, "Rex", "Siamese", "Sean", "456 Greenwood ave", 25,true, "4/20/1993");
		Cat t5 = new Cat( 5, "Bella", "Maine Coon", "Erik", "567 main st", 26,true, "3/9/1992");
		Cat t6 = new Cat( 6, "Ace", "Sphynx", "Gizelle", "678 main st", 37,false, "2/17/1981");
		Cat t7 = new Cat( 7, "Pixie", "Tabby", "Elizabeth","13 drewery ln", 27,false, "1/1/1991");
		
		
		List<Cat> cats = Arrays.asList(t1,t2,t3,t4,t5,t6,t7);
		catRepository.saveAll(cats);
	
	}
}
